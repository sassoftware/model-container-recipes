import argparse
import numpy
import pandas
import pickle
import sympy 

import statsmodels.api as smodel

parser = argparse.ArgumentParser(description='Train')
parser.add_argument('-i', dest='trainInputCSV', required=True, help='input filename')
parser.add_argument('-o', dest='modelFile', required=True, help='output model filename')
args = parser.parse_args()
train_input_csv = args.trainInputCSV
model_file = args.modelFile

# Define the prefix for model specific file name
prefixModelFile = str('hmeq_logistic')

# Define the analysis variable
yName = 'BAD'
catName = ['JOB', 'REASON']
intName = ['CLAGE', 'CLNO', 'DEBTINC', 'DELINQ', 'DEROG', 'NINQ', 'YOJ']

# Read the input data
inputData = pandas.read_csv(train_input_csv, sep = ',',
                            usecols = [yName] + catName + intName)

# Define the training data and drop the missing values
useColumn = [yName]
useColumn.extend(catName + intName)
trainData = inputData[useColumn].dropna()

# STEP 1: Explore the data

# Describe the interval variables grouped by category of the target variable
print(trainData.groupby(yName).size())

# STEP 2: Build the multinominal logistic model

# Threshold for the misclassification error (BAD: 0-No, 1-Yes)
threshPredProb = numpy.mean(trainData[yName])

# Specify the categorical target variable
y = trainData[yName].astype('category')

# Retrieve the categories of the target variable
y_category = y.cat.categories
nYCat = len(y_category)

# Specify the categorical predictors and generate dummy indicator variables
fullX = pandas.get_dummies(trainData[catName].astype('category'))

# Specify the interval predictors and append to the design matrix
fullX = fullX.join(trainData[intName])

# Specify the multinomial logistic model
fullX = smodel.add_constant(fullX, prepend = True)

# Find the non-redundant columns in the design matrix fullX
reduced_form, inds = sympy.Matrix(fullX.values).rref()

# Extract only the non-redundant columns for modeling
print(inds)
X = fullX.iloc[:, list(inds)]

# The number of free parameters
thisDF = len(inds) * (nYCat - 1)

logit = smodel.MNLogit(y, X)

print("Name of Target Variable:", logit.endog_names)
print("Name(s) of Predictors:", logit.exog_names)

# Build the multinomial logistic model
thisFit = logit.fit(method = 'newton', full_output = True, maxiter = 100, tol = 1e-12)
print(thisFit.summary())

# Rename the columns of the parameter estimates for human to read
thisParameter = thisFit.params
thisParameter = thisParameter.rename(columns = {0: 'BAD = 1'})

print("Model Parameter Estimates:\n", thisParameter)
print("Model Log-Likelihood Value:\n", logit.loglike(thisParameter.values))

# Open a writable binary file for saving the pickle object
pFile = open(model_file, 'wb')
pickle.dump(thisFit, pFile)
pFile.close() 
print("Saved model at ", model_file)
