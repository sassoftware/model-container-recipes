import numpy
import pandas
import pickle
import settings

def scoreHMEQLogisticModel (JOB, REASON, CLAGE, CLNO, DEBTINC, DELINQ, DEROG, NINQ):
    "Output: EM_EVENTPROBABILITY, EM_CLASSIFICATION"

    try:
       _thisModelFit
    except NameError:
       _pFile = open(settings.pickle_path + "hmeq_logistic.pickle", "rb")
       _thisModelFit = pickle.load(_pFile)
       _pFile.close()

    cStr = JOB.strip()
    JOB_Mgr = numpy.where(cStr == "Mgr", 1.0, 0.0)
    JOB_Office = numpy.where(cStr == "Office", 1.0, 0.0)
    JOB_Other = numpy.where(cStr == "Other", 1.0, 0.0)
    JOB_ProfExe = numpy.where(cStr == "ProfExe", 1.0, 0.0)
    JOB_Sales = numpy.where(cStr == "Sales", 1.0, 0.0)

    cStr = REASON.strip()
    REASON_DebtCon = numpy.where(REASON == 'DebtCon', 1.0, 0.0)

    # Construct the input array for scoring (the first term is for the Intercept)
    input_array = pandas.DataFrame([[1.0, JOB_Mgr, JOB_Office, JOB_Other, JOB_ProfExe, JOB_Sales, \
                                     REASON_DebtCon, CLAGE, CLNO, DEBTINC, DELINQ, DEROG, NINQ]],
        columns = ["const", "JOB_Mgr", "JOB_Office", "JOB_Other", "JOB_ProfExe", "JOB_Sales", \
                   "REASON_DebtCon", "CLAGE", "CLNO", "DEBTINC", "DELINQ", "DEROG", "NINQ"],
        dtype = float)

    # Calculate the predicted probabilities
    _predProb = _thisModelFit.predict(input_array)

    # Retrieve the event probability
    EM_EVENTPROBABILITY = float(_predProb[1])

    # Determine the predicted target category
    EM_CLASSIFICATION = _predProb.idxmax(axis = 1).to_string(index=False)

    return(EM_EVENTPROBABILITY, EM_CLASSIFICATION)